using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using VncSharp;

namespace VncSharpClient
{
	/// <summary>
	/// Summary description for VncSharpClientForm.
	/// </summary>
	public class VncSharpClientForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuFullScreenRefresh;
		private System.Windows.Forms.MenuItem mnuSendCtrlAltDel;
		private System.Windows.Forms.MenuItem mnuSendAltF4;
		private System.Windows.Forms.MenuItem mnuSendCtrlAltEsc;
		private System.Windows.Forms.MenuItem mnuSendCtrl;
		private System.Windows.Forms.MenuItem mnuSendAlt;
		private System.Windows.Forms.MenuItem mnuConnect;
		private System.Windows.Forms.MenuItem mnuDisconnect;
		private System.Windows.Forms.MenuItem menuItem1;

		// The required RemoteDeskop control.  Notice that I'm doing this
		// through code rather than with the VS.NET designer.  You could do 
		// it that way too, but I wanted to show the code only method.
		private RemoteDesktop rd = null;

		public VncSharpClientForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			// Here I instantiate the RemoteDesktop, make it take the
			// entire Client Area of the form, and have it start drawing.
			rd = new RemoteDesktop();
			rd.Dock = DockStyle.Fill;
			rd.Location = new Point(0, 0);
			this.Controls.Add(rd);
			
			// These events are wired so that I'll know when connections are
			// completed or lost.
			rd.ConnectComplete += new ConnectCompleteHandler(ConnectComplete);
			rd.ConnectionLost += new EventHandler(ConnectionLost);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuConnect = new System.Windows.Forms.MenuItem();
			this.mnuDisconnect = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuFullScreenRefresh = new System.Windows.Forms.MenuItem();
			this.mnuSendCtrlAltDel = new System.Windows.Forms.MenuItem();
			this.mnuSendAltF4 = new System.Windows.Forms.MenuItem();
			this.mnuSendCtrlAltEsc = new System.Windows.Forms.MenuItem();
			this.mnuSendCtrl = new System.Windows.Forms.MenuItem();
			this.mnuSendAlt = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuConnect,
																					this.mnuDisconnect,
																					this.menuItem1,
																					this.mnuFullScreenRefresh,
																					this.mnuSendCtrlAltDel,
																					this.mnuSendAltF4,
																					this.mnuSendCtrlAltEsc,
																					this.mnuSendCtrl,
																					this.mnuSendAlt});
			this.mnuFile.Text = "&File";
			// 
			// mnuConnect
			// 
			this.mnuConnect.Index = 0;
			this.mnuConnect.Text = "Connect...";
			this.mnuConnect.Click += new System.EventHandler(this.mnuConnect_Click);
			// 
			// mnuDisconnect
			// 
			this.mnuDisconnect.Index = 1;
			this.mnuDisconnect.Text = "Disconnect";
			this.mnuDisconnect.Click += new System.EventHandler(this.mnuDisconnect_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 2;
			this.menuItem1.Text = "-";
			// 
			// mnuFullScreenRefresh
			// 
			this.mnuFullScreenRefresh.Index = 3;
			this.mnuFullScreenRefresh.Text = "Full Screen Refresh";
			this.mnuFullScreenRefresh.Click += new System.EventHandler(this.mnuFullScreenRefresh_Click);
			// 
			// mnuSendCtrlAltDel
			// 
			this.mnuSendCtrlAltDel.Index = 4;
			this.mnuSendCtrlAltDel.Text = "Send CTRL+ALT+DEL";
			this.mnuSendCtrlAltDel.Click += new System.EventHandler(this.mnuSendCtrlAltDel_Click);
			// 
			// mnuSendAltF4
			// 
			this.mnuSendAltF4.Index = 5;
			this.mnuSendAltF4.Text = "Send ALT+F4";
			this.mnuSendAltF4.Click += new System.EventHandler(this.mnuSendAltF4_Click);
			// 
			// mnuSendCtrlAltEsc
			// 
			this.mnuSendCtrlAltEsc.Index = 6;
			this.mnuSendCtrlAltEsc.Text = "Send CTRL+ESC";
			this.mnuSendCtrlAltEsc.Click += new System.EventHandler(this.mnuSendCtrlAltEsc_Click);
			// 
			// mnuSendCtrl
			// 
			this.mnuSendCtrl.Index = 7;
			this.mnuSendCtrl.Text = "Send CTRL";
			this.mnuSendCtrl.Click += new System.EventHandler(this.mnuSendCtrl_Click);
			// 
			// mnuSendAlt
			// 
			this.mnuSendAlt.Index = 8;
			this.mnuSendAlt.Text = "Send ALT";
			this.mnuSendAlt.Click += new System.EventHandler(this.mnuSendAlt_Click);
			// 
			// VncSharpClientForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 428);
			this.Menu = this.mainMenu1;
			this.Name = "VncSharpClientForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "VncSharp Client Form Example";

		}
		#endregion

		protected void ConnectComplete(object sender,ConnectEventArgs e)
		{
			// Update the Form to match the geometry of remote desktop.
			ClientSize = new Size(e.DesktopWidth, e.DesktopHeight);

			// Change the Form's title to match the remote desktop name
			Text = e.DesktopName;
		}
				
		protected void ConnectionLost(object sender, EventArgs e)
		{
			// Let the user know of the lost connection
			MessageBox.Show(this,
							"Lost Connection to Host.",
						    "Connection Lost",
						    MessageBoxButtons.OK,
						    MessageBoxIcon.Information);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			// If the user tries to close the window without doing a clean
			// shutdown of the remote connection, do it for them.
			if (rd.IsConnected) {
				rd.Disconnect();
			}
			base.OnClosing (e);
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new VncSharpClientForm());
		}

		private void mnuFullScreenRefresh_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Request a Full Screen Refresh.  Useful for when the image gets corrupted.
			rd.FullScreenUpdate();
		}

		private void mnuSendCtrlAltDel_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Send CTRL+ALT+DEL (task manager, login, etc.) to remote host
			rd.SendSpecialKeys(SpecialKeys.CtrlAltDel);
		}

		private void mnuSendAltF4_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Send ALT+F4 (close current window) to remote host
			rd.SendSpecialKeys(SpecialKeys.AltF4);
		}

		private void mnuSendCtrlAltEsc_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Send CTRL+ESC (Start menu) to remote host
			rd.SendSpecialKeys(SpecialKeys.CtrlEsc);
		}

		private void mnuSendCtrl_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Send the CTRL key, which you can then follow with another key.
			// This is useful when CTRL and the other key would cause something
			// to happen locally and you only want it to happen remotely (e.g.,
			// CTRL+O for Open).
			rd.SendSpecialKeys(SpecialKeys.Ctrl);
		}

		private void mnuSendAlt_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Send the ALT key, which you can then follow with another key.
			// This is useful when ALT and the other key would cause something
			// to happen locally and you only want it to happen remotely (e.g.,
			// ALT+F for File Menu).
			rd.SendSpecialKeys(SpecialKeys.Alt);
		}

		private void mnuConnect_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Get a host name from the user.
			string host = ConnectDialog.GetVncHost();

			// As long as they didn't click Cancel, try to connect
			if (host != null)
				try {
					rd.Connect(host);
				} catch (VncProtocolException vex) {
					MessageBox.Show(this,
									string.Format("Unable to connect to VNC host:\n\n{0}.\n\nCheck that a VNC host is running there.", vex.Message),
								    string.Format("Unable to Connect to {0}", host),
								    MessageBoxButtons.OK,
									MessageBoxIcon.Exclamation);
				}
		}

		private void mnuDisconnect_Click(object sender, System.EventArgs e)
		{
			if (!rd.IsConnected)
				return;

			// Disconnect from the remote host if connected.
			if (rd.IsConnected) {
				rd.Disconnect();
			}
		}
	}
}
