For easy distribution, this archive provides the dll form of ZedGraph only.
This distribution of the ZedGraph source code includes two versions:

Version 4.6.x is the .Net 1.1 compatible version
Version 5.1.x is the .Net 2.0 compatible version

Complete source code for ZedGraph is available on sourceforge here:

    http://sourceforge.net/projects/zedgraph/

A wiki providing help, samples, etc. is available here:

    http://zedgraph.org
    
A tutorial on using ZedGraph is available here:

http://www.codeproject.com/csharp/zedgraph.asp



